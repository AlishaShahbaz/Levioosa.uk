const FeatureSection6 = () => {
  return <div>FeatureSection6</div>
}

export default FeatureSection6
