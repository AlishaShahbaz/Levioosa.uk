export interface TImage {
  src: string
  width?: number
  height?: number
  alt: string
  sizes?: string
}
