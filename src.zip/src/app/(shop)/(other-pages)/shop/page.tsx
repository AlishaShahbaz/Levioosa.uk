import { redirect } from 'next/navigation'

const Page = () => {
  return redirect('/collections/all')
}

export default Page
