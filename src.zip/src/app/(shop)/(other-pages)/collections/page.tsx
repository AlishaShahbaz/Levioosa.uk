import { redirect } from 'next/navigation'

const Collections = () => {
  return redirect('/collections/all')
}

export default Collections
